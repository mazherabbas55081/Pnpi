# PNPI - Pak Navy Polytechnic Institute

A Python + Streamlit website for Pak Navy Polytechnic Institute (PNPI), West Wharf Road, Karachi.

## Features

- PNPI home page
- Mechatronic Engineering program
- Semester-wise subjects
- Faculty and courses
- Student result portal
- Campus life
- Cricket and canteen section
- Professional green/white design
- Image support

## Run locally

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Streamlit Community Cloud

1. Upload all project files to a GitHub repository.
2. Open Streamlit Community Cloud.
3. Select **Create app**.
4. Select your GitHub repository.
5. Select the branch containing the project.
6. Set the main file to:

```text
app.py
```

7. Deploy.

## Image files

Put these images in the same GitHub repository folder as `app.py` if you want them displayed:

- logo.png
- college.png
- classroom.png
- lab1.png
- lab2.png
- lab3.png
- library.png
- cricket1.png
- cricket2.png
- cricket3.png
- canteen.png

The app will still run if an image is missing; it will show a small message instead.
